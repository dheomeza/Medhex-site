
export default function About() {
  return (
    <div style={{ padding: 40 }}>
      <h1>About Medhex Consulting</h1>
      <p>We are specialists in risk advisory, AML/CFT, internal audit and investigations.</p>
    </div>
  );
}
